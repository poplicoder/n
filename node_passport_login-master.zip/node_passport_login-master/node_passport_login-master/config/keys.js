dbPassword = 'mongodb+srv://geet_16:coding@geeteshcn.f0jyk.mongodb.net/test?retryWrites=true&w=majority';

module.exports = {
    mongoURI: dbPassword
};
